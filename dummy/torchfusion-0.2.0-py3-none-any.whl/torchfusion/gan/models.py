import torch
from torch.autograd import Variable


import torch
from torch.autograd import Variable
import torch.cuda as cuda
#from ..utils import *
from torchvision import utils as vutils
import os
from time import time
import numpy as np
import matplotlib.pyplot as plt

class BaseGANModel():
    def __init__(self, gen_model,disc_model,use_cuda_if_available=True):
        self.model_dir = os.getcwd()
        self.gen_model = gen_model
        self.disc_model = disc_model
        self.cuda = False
        if use_cuda_if_available and cuda.is_available():
            self.cuda = True

        print("cuda: ",self.cuda)

    def load_generator(self, path):
        checkpoint = torch.load(path)
        self.gen_model.load_state_dict(checkpoint)

    def load_discriminator(self, path):
        checkpoint = torch.load(path)
        self.disc_model.load_state_dict(checkpoint)

    def save_generator(self, path):
        torch.save(self.gen_model.state_dict(), path)

    def save_discriminator(self, path):
        torch.save(self.disc_model.state_dict(), path)

    def train(self, target,source, gen_loss_fn,disc_loss_fn, gen_optimizer,disc_optimizer,metrics, num_epochs=10, disc_steps=1, gen_lr_schedule=None,disc_lr_schedule=None, model_dir=os.getcwd(), save_interval=100):
        assert(len(target.dataset) == len(source.dataset))
        assert(disc_steps < len(target.dataset))

        self.model_dir = model_dir
        models_gen = os.path.join(model_dir, "gen_models")
        models_disc = os.path.join(model_dir, "disc_models")

        if not os.path.exists(models_gen):
            os.mkdir(models_gen)

        if not os.path.exists(models_disc):
            os.mkdir(models_disc)

        iterations = 0
        for e in range(num_epochs):

            #for metric in metrics:
                #metric.reset()

            self.gen_model.train()
            self.disc_model.train()
            self.on_epoch_start(e)

            #best_metric = 0.0
            running_gen_loss = torch.Tensor([0.0])
            running_disc_loss = torch.Tensor([0.0])
            gen_loss = 0.0
            disc_loss = 0.0
            gen_data_len = 0
            disc_data_len = 0

            init_time = time()

            target_iter = iter(target)
            source_iter = iter(source)

            i = 0
            while i < len(target ):
                self.on_batch_start(e,i)
                d_steps = disc_steps
                if (i + d_steps) > (len(target) - 1):
                    d_steps = 1
                print("I: {} D: {}".format(i,d_steps))
                for step in range(d_steps):
                    t = target_iter.next()
                    s = source_iter.next()

                    self.__disc_train_func__(t,s,disc_optimizer,disc_loss_fn,metrics,running_disc_loss,e,i)

                    if i % save_interval == 0:
                        self.save(s,iterations)
                        self.show(s,iterations)
                    disc_data_len += t[0].size(0)
                    i += 1
                    iterations += 1

                    if step == d_steps - 1:
                        self.__gen_train_func__(t, s, gen_optimizer, gen_loss_fn, metrics, running_gen_loss,e,i-1)
                        gen_data_len += t[0].size(0)

                        #gen_loss = running_gen_loss.item() / gen_data_len
                        #disc_loss = running_disc_loss.item() / disc_data_len
                        gen_loss = running_gen_loss.data[0] / gen_data_len
                        disc_loss = running_disc_loss.data[0] / disc_data_len

                        self.on_batch_end(e, i-1, metrics, gen_loss, disc_loss)



            duration = time() - init_time

            if gen_lr_schedule is not None:
                lr = gen_lr_schedule(e)
                for param_group in gen_optimizer.param_groups:
                    param_group["lr"] = lr

            if disc_lr_schedule is not None:
                lr = disc_lr_schedule(e)
                for param_group in disc_optimizer.param_groups:
                    param_group["lr"] = lr

            model_file = os.path.join(models_gen, "gen_model_{}.pth".format(e))
            self.save_generator(model_file)

            model_file = os.path.join(models_disc, "disc_model_{}.pth".format(e))
            self.save_discriminator(model_file)

            print("Epoch: {}, Duration: {} , Gen Loss: {} Disc: {}".format(e, duration, gen_loss,disc_loss))

            #for metric in metrics:
                #print("Train {} : {}".format(metric.name, metric.getValue()))

            self.on_epoch_end(e,metrics, gen_loss, disc_loss, duration)

    def __gen_train_func__(self,target,source,gen_optimizer,loss_fn,metrics,running_loss,epoch,batch_num):
        raise NotImplementedError()

    def __disc_train_func__(self,target,source,disc_optimizer,loss_fn,metrics,running_loss,epoch,batch_num):
        raise NotImplementedError()

    def save(self,source,iterations):
        raise NotImplementedError()

    def show(self,source,iterations):
        raise NotImplementedError()

    def evaluate(self, test_loader, metrics):

        self.gen_model.eval()
        for metric in metrics:
            metric.reset()

        for i, data in enumerate(test_loader):
            self.__eval_function__(data,metrics)


    def __eval_function__(self,data,metrics):
        pass

    def predict(self, *args):
        pass

    def on_epoch_start(self, epoch):
        pass

    def on_epoch_end(self, epoch,metrics,gen_loss,disc_loss,duration):
        pass

    def on_batch_start(self, epoch, batch_num):
        pass

    def on_batch_end(self, epoch, batch_num, metrics, gen_loss,disc_loss):
        pass

    def on_training_completed(self, metrics, gen_loss, disc_loss):
        pass


class MLPGANModel(BaseGANModel):
    def __init__(self,gen_model,disc_model,use_cuda_if_available=True,clip_gradients=None):
        super(MLPGANModel,self).__init__(gen_model,disc_model,use_cuda_if_available)

        self.clip_grads = clip_gradients


    def __disc_train_func__(self,target,source,disc_optimizer,loss_fn,metrics,running_loss,epoch,batch_num,*args):
        disc_optimizer.zero_grad()
        x, _ = target
        batch_size = x.size(0)

        x_size = x.size(1)


        real_labels = torch.ones(batch_size, 1)
        fake_labels = torch.zeros(batch_size, 1)

        for i in range(len(x.size()) - 1):
            x_size *= x.size(i + 1)

        x = x.view(-1, x_size)

        if self.cuda:
            x = x.cuda()
            source = source.cuda()
            real_labels = real_labels.cuda()
            fake_labels = fake_labels.cuda()
        x = Variable(x)
        source = Variable(source)
        real_labels = Variable(real_labels)
        fake_labels = Variable(fake_labels)

        outputs = self.disc_model(x)

        real_loss = loss_fn(outputs,real_labels)
        real_loss.backward()

        generated = self.gen_model(source)
        gen_outputs = self.disc_model(generated.detach())

        fake_loss = loss_fn(gen_outputs,fake_labels)
        fake_loss.backward()

        disc_optimizer.step()

        if self.clip_grads is not None:
            for param in self.disc_model.parameters():
                param.data.clamp_(self.clip_grads[0],self.clip_grads[1])


        d_loss = real_loss + fake_loss

        running_loss.add_(d_loss.cpu() * batch_size)

    def __gen_train_func__(self,target,source,optimizer,loss_fn,metrics,running_loss,epoch,batch_num,*args):

        optimizer.zero_grad()

        x, y = target
        batch_size = x.size(0)
        labels = torch.ones(batch_size, 1)

        if self.cuda:
            source = source.cuda()
            labels = labels.cuda()

        source = Variable(source)
        labels = Variable(labels)

        fake_images = self.gen_model(source)
        outputs = self.disc_model(fake_images)

        loss = loss_fn(outputs, labels)
        loss.backward()

        optimizer.step()

        running_loss.add_(loss.cpu() * batch_size)

    def save(self,source,iteration):

        save_dir = os.path.join(self.model_dir,"gen_images")

        if os.path.exists(save_dir) == False:
            os.mkdir(save_dir)
        images_file = os.path.join(save_dir,"image_{}.png".format(iteration))

        if self.cuda:
            source = source.cuda()

        source = Variable(source)
        outputs = self.gen_model(source)
        img = outputs.data.view(-1,1,28,28)

        vutils.save_image(img.cpu().dcata,images_file,normalize=True)

    def show(self,source,iteration):

        if self.cuda:
            source = source.cuda()

        source = Variable(source)
        outputs = self.gen_model(source)
        img = outputs.data.view(-1, 1,28,28)

        images = vutils.make_grid(img.cpu().data,normalize=True)

        images = np.transpose(images.numpy(),(1,2,0))
        plt.imshow(images)
        plt.show()


class ConvGANModel(BaseGANModel):
    def __init__(self, gen_model, disc_model, use_cuda_if_available=True):
        super(ConvGANModel, self).__init__(gen_model, disc_model, use_cuda_if_available)

    def __disc_train_func__(self, target, source, disc_optimizer, loss_fn, metrics, running_loss, epoch, batch_num):
        disc_optimizer.zero_grad()
        x, _ = target
        batch_size = x.size(0)

        real_labels = torch.ones(batch_size, 1)
        fake_labels = torch.zeros(batch_size, 1)

        if self.cuda:
            x = x.cuda()
            source = source.cuda()
            real_labels = real_labels.cuda()
            fake_labels = fake_labels.cuda()

        x = Variable(x)
        source = Variable(source)
        real_labels = Variable(real_labels)
        fake_labels = Variable(fake_labels)

        outputs = self.disc_model(x)

        real_loss = loss_fn(outputs, real_labels)
        real_loss.backward()

        generated = self.gen_model(source)
        gen_outputs = self.disc_model(generated.detach())

        fake_loss = loss_fn(gen_outputs, fake_labels)
        fake_loss.backward()

        disc_optimizer.step()

        d_loss = real_loss + fake_loss

        running_loss.add_(d_loss.cpu() * batch_size)

    def __gen_train_func__(self, target, source, optimizer, loss_fn, metrics, running_loss, epoch, batch_num):

        optimizer.zero_grad()

        x, y = target
        batch_size = x.size(0)
        labels = torch.ones(batch_size,1)

        if self.cuda:
            source = source.cuda()
            labels = labels.cuda()

        source = Variable(source)
        labels = Variable(labels)

        fake_images = self.gen_model(source)
        outputs = self.disc_model(fake_images)

        loss = loss_fn(outputs, labels)
        loss.backward()

        optimizer.step()

        running_loss.add_(loss.cpu() * batch_size)

    def save(self, source, iteration):

        save_dir = os.path.join(self.model_dir, "gen_images")

        if os.path.exists(save_dir) == False:
            os.mkdir(save_dir)
        images_file = os.path.join(save_dir, "image_{}.png".format(iteration))

        if self.cuda:
            source = source.cuda()

        source = Variable(source)
        outputs = self.gen_model(source)
        vutils.save_image(outputs.cpu().data, images_file, normalize=True)

    def show(self, source, iteration):

        if self.cuda:
            source = source.cuda()

        source = Variable(source)
        outputs = self.gen_model(source)

        images = vutils.make_grid(outputs.cpu().data, normalize=True)

        images = np.transpose(images.numpy(), (1, 2, 0))
        plt.imshow(images)
        plt.show()


