import torch

class WassersteinDiscLoss(object):
    def __init__(self):
       self.name = ""


    def __call__(self, real, generated):

        loss = -(torch.mean(real) - torch.mean(generated))

        return loss


class WassersteinGenLoss(object):
    def __init__(self):
        self.name = ""

    def __call__(self, generated):
        loss = -(torch.mean(generated))

        return loss



